<?php
$SHOW_EVENTS_BASE_ID = "show_events_";
$GRAPH_BASE_ID = "graph_img_";
?>